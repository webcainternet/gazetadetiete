<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="themify_field_row">
		<a href="#" class="button themify_builder_switch_btn"><?php _e('Switch to Themify Builder', 'themify') ?></a>
</div>